import React from 'react';
import { Head } from '@inertiajs/inertia-react';
import AppLayout from '@/Layouts/AppLayout';

export default function GameIndex(props) {
    return (
        <AppLayout {...props}>
            <Head title="Games" />

            game
        </AppLayout>
    );
}
